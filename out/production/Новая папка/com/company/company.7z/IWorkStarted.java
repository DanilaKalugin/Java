package com.company;

public interface IWorkStarted {
    void WorkStarted();
}
