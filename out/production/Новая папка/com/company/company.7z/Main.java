package com.company;

import java.io.*;
import java.util.*;

public class Main {

    public static void main(String[] args) throws IOException {
        FileReader fr = new FileReader("EmployeesAndVisitors_out.txt");
        ArrayList<Man> peopleList = new ArrayList<Man>();
        Scanner s = new Scanner(fr);
        while(s.hasNextLine())
        {
            String[] strings = s.nextLine().split("\t");

            if (strings[0].equals("Visitor"))
            {
                peopleList.add(new Visitor(strings[1], Boolean.parseBoolean(strings[2]), Integer.parseInt(strings[3]), Integer.parseInt(strings[4]), Integer.parseInt(strings[5]), Integer.parseInt(strings[6])));
            }
            else if(strings[0].equals("Cleaner"))
            {
                peopleList.add(new Cleaner(strings[1], Boolean.parseBoolean(strings[2]), Integer.parseInt(strings[3]), Integer.parseInt(strings[4]), Integer.parseInt(strings[5]), Integer.parseInt(strings[6]), strings[7], Integer.parseInt(strings[8]), strings[9], strings[10]));
            }
            else if(strings[0].equals("Librarian"))
            {
                peopleList.add(new Librarian(strings[1], Boolean.parseBoolean(strings[2]), Integer.parseInt(strings[3]), Integer.parseInt(strings[4]), Integer.parseInt(strings[5]), Integer.parseInt(strings[6]), strings[7], strings[8], strings[9], Integer.parseInt(strings[10])));
            }
        }

        fr.close();

        System.out.println("Man Type:");
        DynamicArray<String> prof = new DynamicArray<String>();
        for (int i=0; i<peopleList.size(); i++)
        {
            prof.Add(peopleList.get(i).getManType());
        }
        System.out.println(prof.DifferentItemsWithCount());

        System.out.println("Name:");
        DynamicArray<String> fio = new DynamicArray<String>();
        for (int i=0; i<peopleList.size(); i++)
            fio.Add(peopleList.get(i).getName());
        System.out.println(fio.DifferentItemsWithCount());

        System.out.println("Name:");
        DynamicArray<Boolean> sex = new DynamicArray<Boolean>();
        for (int i=0; i<peopleList.size(); i++)
            sex.Add(peopleList.get(i).getSex());
        System.out.println(sex.DifferentItemsWithCount());

        System.out.println("Age:");
        DynamicArray<Integer> by = new DynamicArray<Integer>();
        for (int i=0; i<peopleList.size(); i++)
            by.Add(peopleList.get(i).getAge());
        System.out.println(by.DifferentItemsWithCount());
    }
}